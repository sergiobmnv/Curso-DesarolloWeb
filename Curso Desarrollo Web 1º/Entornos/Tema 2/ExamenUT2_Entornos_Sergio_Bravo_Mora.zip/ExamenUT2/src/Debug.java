
public class Debug {

	public static void main(String[] args) {

		int n1, n2, producto;
		n1 = 9;
		n2 = 8;
		producto = n1 * n2;
		if ((producto>100)&&(n1 <= 8)) {
			System.out.println("El producto " + producto + " es mayor que 100");
		}
	}

}
