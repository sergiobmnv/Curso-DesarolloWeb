import java.util.Scanner;

public class AnalisisDatos {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
	
		do {
			
			System.out.println("Inserte un numero");
			int numero = sc.nextInt();
			
			if (numero)
			
			
		}while 
		
		
		
			
		
		
		
	}

}
