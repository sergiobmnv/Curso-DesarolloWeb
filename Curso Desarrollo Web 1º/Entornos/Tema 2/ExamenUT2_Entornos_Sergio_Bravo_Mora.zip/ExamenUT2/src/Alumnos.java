import java.util.Scanner;

public class Alumnos {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Inserte la edad del primer alumno");
		int edad1 = sc.nextInt();
		System.out.println("Inserte la altura del primer alumno");
		int altura1 = sc.nextInt();
		
		System.out.println("Inserte la edad del segundo alumno");
		int edad2 = sc.nextInt();
		System.out.println("Inserte la altura del segundo alumno");
		int altura2 = sc.nextInt();
		
		System.out.println("Inserte la edad del tercero alumno");
		int edad3 = sc.nextInt();
		System.out.println("Inserte la altura del tercero alumno");
		int altura3 = sc.nextInt();
		
		System.out.println("Inserte la edad del cuarto  alumno");
		int edad4 = sc.nextInt();
		System.out.println("Inserte la altura del cuarto alumno");
		int altura4 = sc.nextInt();
		
		System.out.println("Inserte la edad del quinto alumno");
		int edad5 = sc.nextInt();
		System.out.println("Inserte la altura del quinto alumno");
		int altura5 = sc.nextInt();
		
		int sumaedad = edad1 + edad2 + edad3 + edad4 + edad5;
		int edadmedia = sumaedad / 5;
		System.out.println("La edad media entre los 5 alumnos es: " + edadmedia);
		int sumaaltura = altura1 + altura2 + altura3 + altura4 + altura5;
		int alturamedia = sumaaltura / 5;
		System.out.println("La altura media entre los 5 alumnos es: " + alturamedia);
	}

}
